<?php
if (!defined('ABSPATH')) exit;

function pstc_calculate_tax($salary, $type) {
    $annual_salary = ($type === 'monthly') ? $salary * 12 : $salary;
    $slabs = pstc_get_tax_slabs();

    foreach ($slabs as $slab) {
        if ($annual_salary >= $slab['min'] && $annual_salary <= $slab['max']) {
            $tax = $slab['fixed'] + (($annual_salary - $slab['min']) * $slab['rate']);
            break;
        }
    }

    $monthly_tax = $tax / 12;
    $effective_rate = ($tax / $annual_salary) * 100;

    return [
        'annual_salary' => number_format($annual_salary, 2),
        'annual_tax' => number_format($tax, 2),
        'monthly_tax' => number_format($monthly_tax, 2),
        'effective_rate' => number_format($effective_rate, 2)
    ];
}
