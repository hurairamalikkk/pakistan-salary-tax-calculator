<?php
if (!defined('ABSPATH')) exit;

function pstc_get_tax_slabs() {
    return [
        ['min' => 0, 'max' => 600000, 'fixed' => 0, 'rate' => 0],
        ['min' => 600001, 'max' => 1200000, 'fixed' => 0, 'rate' => 0.05],
        ['min' => 1200001, 'max' => 2400000, 'fixed' => 30000, 'rate' => 0.125],
        ['min' => 2400001, 'max' => 3600000, 'fixed' => 180000, 'rate' => 0.20],
        ['min' => 3600001, 'max' => 6000000, 'fixed' => 420000, 'rate' => 0.25],
        ['min' => 6000001, 'max' => INF, 'fixed' => 1020000, 'rate' => 0.35],
    ];
}
