<?php
/**
 * Plugin Name: Pakistan Salary Tax Calculator
 * Description: Calculates Pakistan salaried income tax based on FBR slabs.
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

define('PSTC_PATH', plugin_dir_path(__FILE__));
define('PSTC_URL', plugin_dir_url(__FILE__));

require_once PSTC_PATH . 'includes/tax-slabs.php';
require_once PSTC_PATH . 'includes/calculator-functions.php';

/**
 * Enqueue assets
 */
function pstc_enqueue_assets() {
    wp_enqueue_style('pstc-style', PSTC_URL . 'assets/css/style.css');
    wp_enqueue_script('pstc-script', PSTC_URL . 'assets/js/script.js', [], null, true);
    wp_localize_script('pstc-script', 'pstc_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('pstc_nonce')
    ]);
}
add_action('wp_enqueue_scripts', 'pstc_enqueue_assets');

/**
 * Shortcode
 */
function pstc_render_calculator() {
    if (!get_option('pstc_enabled', 1)) return '';

    ob_start(); ?>
    <div class="pstc-wrapper">
        <input type="number" id="pstc-salary" placeholder="Enter Salary" min="0">
        <select id="pstc-type">
            <option value="monthly">Monthly</option>
            <option value="annual">Annual</option>
        </select>
        <button id="pstc-calc">Calculate</button>

        <div id="pstc-result"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('pakistan_salary_tax_calculator', 'pstc_render_calculator');

/**
 * AJAX Handler
 */
function pstc_calculate_tax_ajax() {
    check_ajax_referer('pstc_nonce', 'nonce');

    $salary = isset($_POST['salary']) ? floatval($_POST['salary']) : 0;
    $type   = sanitize_text_field($_POST['type']);

    if ($salary < 0) wp_send_json_error('Invalid salary');

    $result = pstc_calculate_tax($salary, $type);
    wp_send_json_success($result);
}
add_action('wp_ajax_pstc_calculate_tax', 'pstc_calculate_tax_ajax');
add_action('wp_ajax_nopriv_pstc_calculate_tax', 'pstc_calculate_tax_ajax');

/**
 * Admin Settings
 */
function pstc_register_settings() {
    register_setting('pstc_settings', 'pstc_enabled');
    register_setting('pstc_settings', 'pstc_disclaimer');
}
add_action('admin_init', 'pstc_register_settings');

function pstc_settings_page() {
    add_options_page('Salary Tax Calculator', 'Salary Tax Calculator', 'manage_options', 'pstc-settings', function() {
        ?>
        <div class="wrap">
            <h1>Pakistan Salary Tax Calculator</h1>
            <form method="post" action="options.php">
                <?php settings_fields('pstc_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th>Enable Calculator</th>
                        <td><input type="checkbox" name="pstc_enabled" value="1" <?php checked(1, get_option('pstc_enabled'), true); ?>></td>
                    </tr>
                    <tr>
                        <th>Disclaimer</th>
                        <td><textarea name="pstc_disclaimer" rows="4" cols="50"><?php echo esc_textarea(get_option('pstc_disclaimer')); ?></textarea></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    });
}
add_action('admin_menu', 'pstc_settings_page');
