document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('pstc-calc').addEventListener('click', function () {
        let salary = document.getElementById('pstc-salary').value;
        let type = document.getElementById('pstc-type').value;

        fetch(pstc_ajax.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=pstc_calculate_tax&salary=${salary}&type=${type}&nonce=${pstc_ajax.nonce}`
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                let r = data.data;
                document.getElementById('pstc-result').innerHTML = `
                    <p>Annual Salary: ${r.annual_salary}</p>
                    <p>Annual Tax: ${r.annual_tax}</p>
                    <p>Monthly Tax: ${r.monthly_tax}</p>
                    <p>Effective Rate: ${r.effective_rate}%</p>
                `;
            }
        });
    });
});
